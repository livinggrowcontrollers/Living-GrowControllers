
import os
import re
import sys
import shutil

class ESPPatcher:
    def __init__(self, root_dir, num_instances=1):
        self.root_dir = os.path.abspath(root_dir)
        self.num_instances = max(1, min(3, num_instances)) # Unterstützt 1 bis 3 Instanzen
        self.base_name = "circulation_fan"
        
        # Regulärer Ausdruck zum Finden von Marker-Blöcken
        self.marker_regex = re.compile(
            r"(//\s*PATCHER\s+BEGIN:\s*(\w+)\s*\n)(.*?)(//\s*PATCHER\s+END:\s*\2\s*)",
            re.DOTALL
        )

    def run(self):
        print(f"Starte Patch-Vorgang im Verzeichnis: {self.root_dir}")
        print(f"Ziel-Instanzanzahl: {self.num_instances}")
        
        try:
            self._manage_module_files()
            patch_registry = self._generate_patch_contents()
            self._apply_patches(patch_registry)
            print("Patch-Vorgang erfolgreich abgeschlossen!")
        except Exception as e:
            print(f"Fehler während des Patchens: {e}", file=sys.stderr)
            sys.exit(1)

    def _manage_module_files(self):
        """Kopiert Moduldateien für Instanzen 2 und 3 oder löscht sie, falls nicht benötigt."""
        src_cpp = os.path.join(self.root_dir, f"{self.base_name}.cpp")
        src_h = os.path.join(self.root_dir, f"{self.base_name}.h")

        if not os.path.exists(src_cpp) or not os.path.exists(src_h):
            raise FileNotFoundError(f"Single Source of Truth ({self.base_name}.cpp/.h) nicht gefunden!")

        for i in range(2, 4):
            dst_cpp = os.path.join(self.root_dir, f"{self.base_name}{i}.cpp")
            dst_h = os.path.join(self.root_dir, f"{self.base_name}{i}.h")

            if i <= self.num_instances:
                # Instanz erstellen/aktualisieren
                self._duplicate_and_rename_module(src_cpp, dst_cpp, i)
                self._duplicate_and_rename_module(src_h, dst_h, i)
            else:
                # Überzählige Instanzen löschen
                if os.path.exists(dst_cpp):
                    os.remove(dst_cpp)
                    print(f"Entfernt: {dst_cpp}")
                if os.path.exists(dst_h):
                    os.remove(dst_h)
                    print(f"Entfernt: {dst_h}")

    def _duplicate_and_rename_module(self, src, dst, instance_num):
        """Kopiert eine Datei und ersetzt Bezeichner passend zur Instanznummer."""
        with open(src, 'r', encoding='utf-8') as f:
            content = f.read()

        # Ersetze Bezeichner (z.B. circulation_fan -> circulation_fan2)
        # Und korrigiert automatisch das #include "circulation_fan.h" -> "circulation_fan2.h"
        modified_content = content.replace(self.base_name, f"{self.base_name}{instance_num}")

        with open(dst, 'w', encoding='utf-8', newline='\n') as f:
            f.write(modified_content)
        print(f"Generiert/Aktualisiert: {dst}")

    def _generate_patch_contents(self):
        """Generiert das Single-Source-of-Truth-Wörterbuch für alle IDs basierend auf der Instanzanzahl."""
        patches = {}
        
        # Hilfsfunktion für Suffixe bei Generierung
        def suf(i): return "" if i == 1 else str(i)

        # --- CIRCULATION_INCLUDE ---
        inc_lines = []
        for i in range(1, self.num_instances + 1):
            inc_lines.append(f'#include "{self.base_name}{suf(i)}.h"')
        patches["CIRCULATION_INCLUDE"] = "\n".join(inc_lines) + "\n"

        # --- CIRCULATION_INIT ---
        init_lines = []
        for i in range(1, self.num_instances + 1):
            s = suf(i)
            init_lines.append(
                f'if (sysConfig.pin_circ_fan{s} == -1 || sysConfig.pin_circ_tacho{s} == -1) {{\n'
                f'    Serial.println("Circulation Fan {s} disabled (sysConfig).");\n'
                f'}} else {{\n'
                f'    circulation_fan{s}_init((uint8_t)sysConfig.pin_circ_fan{s}, (uint8_t)sysConfig.pin_circ_tacho{s});\n'
                f'}}'
            )
        patches["CIRCULATION_INIT"] = "\n".join(init_lines) + "\n"

        # --- CIRCULATION_UPDATE ---
        upd_lines = []
        for i in range(1, self.num_instances + 1):
            upd_lines.append(f'circulation_fan{suf(i)}_update();')
            # Für web_server.cpp Variante (wird über denselben Marker identifiziert)
            # Da derselbe Marker-Name verwendet wird, kombinieren wir die Logik intelligent beim Ersetzen 
            # oder generieren einen universellen Block, falls der Marker im Kontext eindeutig ist.
            # Da 'circulation_fan_process_json(obj);' ebenfalls unter UPDATE lief:
        patches["CIRCULATION_UPDATE"] = "\n".join(upd_lines) + "\n"
        
        # Spezialfall: Falls derselbe ID-Name für zwei unterschiedliche Dinge genutzt wird,
        # weichen wir auf Kontext-Generierung aus. Wir trennen UPDATE (Funktion) und UPDATE (JSON) im RAM:
        patches["CIRCULATION_UPDATE_JSON"] = "\n".join([f'circulation_fan{suf(i)}_process_json(obj);' for i in range(1, self.num_instances + 1)]) + "\n"

        # --- CIRCULATION_GET_STATUS ---
        patches["CIRCULATION_GET_STATUS"] = "\n".join([f'circulation_fan{suf(i)}_get_status(obj);' for i in range(1, self.num_instances + 1)]) + "\n"

        # --- CIRCULATION_CONFIG ---
        conf_lines = []
        for i in range(1, self.num_instances + 1):
            s = suf(i)
            conf_lines.append(f'int pin_circ_fan{s};\nint pin_circ_tacho{s};\nint pin_circ_tacho_pull{s};')
        patches["CIRCULATION_CONFIG"] = "\n".join(conf_lines) + "\n"

        # --- CIRCULATION_CONFIG_DEFAULTS ---
        def_lines = []
        # Standardwerte-Arrays für bis zu 3 Instanzen um Überschneidungen zu verhindern
        defaults = [
            ("45", "2", "1"),  # Instanz 1
            ("46", "3", "1"),  # Instanz 2
            ("47", "4", "1")   # Instanz 3
        ]
        for i in range(1, self.num_instances + 1):
            fan, tacho, pull = defaults[i-1]
            s = suf(i)
            def_lines.append(f'/* pin_circ_fan{s} */ {fan},\n/* pin_circ_tacho{s} */ {tacho},\n/* pin_circ_tacho_pull{s} */ {pull},')
        patches["CIRCULATION_CONFIG_DEFAULTS"] = "\n".join(def_lines) + "\n"

        # --- CIRCULATION_PREFS_LOAD ---
        load_lines = []
        for i in range(1, self.num_instances + 1):
            s = suf(i)
            load_lines.append(
                f'sysConfig.pin_circ_fan{s}        = growPrefs.getInt("p_c_fan{s}", sysConfig.pin_circ_fan{s});\n'
                f'sysConfig.pin_circ_tacho{s}      = growPrefs.getInt("p_c_tac{s}", sysConfig.pin_circ_tacho{s});\n'
                f'sysConfig.pin_circ_tacho_pull{s} = growPrefs.getInt("p_c_tac_pull{s}", sysConfig.pin_circ_tacho_pull{s});'
            )
        patches["CIRCULATION_PREFS_LOAD"] = "\n".join(load_lines) + "\n"

        # --- CIRCULATION_PREFS_SAVE ---
        save_lines = []
        for i in range(1, self.num_instances + 1):
            s = suf(i)
            save_lines.append(
                f'if (doc.containsKey("p_c_fan{s}")) {{\n'
                f'    int v = doc["p_c_fan{s}"];\n'
                f'    growPrefs.putInt("p_c_fan{s}", v);\n'
                f'    sysConfig.pin_circ_fan{s} = v;\n'
                f'    gpio_changed = true;\n'
                f'}}\n'
                f'if (doc.containsKey("p_c_tac_pull{s}")) {{\n'
                f'    int v = doc["p_c_tac_pull{s}"];\n'
                f'    growPrefs.putInt("p_c_tac_pull{s}", v);\n'
                f'    sysConfig.pin_circ_tacho_pull{s} = v;\n'
                f'    gpio_changed = true;\n'
                f'}}\n'
                f'if (doc.containsKey("p_c_tac{s}")) {{\n'
                f'    int v = doc["p_c_tac{s}"];\n'
                f'    growPrefs.putInt("p_c_tac{s}", v);\n'
                f'    sysConfig.pin_circ_tacho{s} = v;\n'
                f'    gpio_changed = true;\n'
                f'}}'
            )
        patches["CIRCULATION_PREFS_SAVE"] = "\n".join(save_lines) + "\n"

        # --- CIRCULATION_RECONFIGURE ---
        patches["CIRCULATION_RECONFIGURE"] = "\n".join([f'circulation_fan{suf(i)}_reconfigure();' for i in range(1, self.num_instances + 1)]) + "\n"

        return patches

    def _apply_patches(self, patch_registry):
        """Durchsucht das Verzeichnis rekursiv und ersetzt alle Marker-Inhalte."""
        for root, _, files in os.walk(self.root_dir):
            for file in files:
                # Moduldateien selbst von den globalen Text-Patches ausschließen
                if file.startswith(self.base_name) and (file.endswith(".cpp") or file.endswith(".h")):
                    continue
                
                # Nur relevante Quellcodedateien patchen
                if file.endswith(('.cpp', '.h', '.ino', '.c')):
                    file_path = os.path.join(root, file)
                    self._patch_single_file(file_path, patch_registry)

    def _patch_single_file(self, file_path, patch_registry):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        modified = False

        def replacer(match):
            nonlocal modified
            begin_marker = match.group(1)
            patch_id = match.group(2)
            end_marker = match.group(4)
            
            # Auflösung des doppelten "CIRCULATION_UPDATE"-Markers anhand des Dateiinhalts/Kontexts
            actual_id = patch_id
            if patch_id == "CIRCULATION_UPDATE" and "process_json" in match.group(3):
                actual_id = "CIRCULATION_UPDATE_JSON"
            elif patch_id == "CIRCULATION_UPDATE" and "web_server" in file_path.lower():
                # Sicherheitsnetz für web_server.cpp
                actual_id = "CIRCULATION_UPDATE_JSON"

            if actual_id in patch_registry:
                modified = True
                return f"{begin_marker}{patch_registry[actual_id]}{end_marker}"
            else:
                # Wenn ID unbekannt, Inhalt unverändert lassen
                return match.group(0)

        new_content = self.marker_regex.sub(replacer, content)

        if modified:
            with open(file_path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(new_content)
            print(f"Datei erfolgreich gepatcht: {file_path}")

if __name__ == "__main__":
    # Standardmäßig im aktuellen Verzeichnis ausführen. 
    # Anzahl der Instanzen hier einstellen (1, 2 oder 3).
    ANZAHL_INSTANZEN = 2 
    
    current_dir = os.getcwd()
    patcher = ESPPatcher(root_dir=current_dir, num_instances=ANZAHL_INSTANZEN)
    patcher.run()

