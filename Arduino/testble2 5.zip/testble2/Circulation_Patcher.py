#!/usr/bin/env python3
import os
import re
import sys

def copy_and_rename_sources(target_instances):
    source_dir = "source_path"
    cpp_src = os.path.join(source_dir, "circulation_fan.cpp")
    h_src = os.path.join(source_dir, "circulation_fan.h")
    
    if not os.path.exists(cpp_src) or not os.path.exists(h_src):
        print(f"Error: Base source files not found in '{source_dir}/'")
        sys.exit(1)
        
    with open(cpp_src, "r", encoding="utf-8") as f:
        cpp_content = f.read()
    with open(h_src, "r", encoding="utf-8") as f:
        h_content = f.read()
        
    for inst in target_instances:
        suffix = str(inst)
        
        def repl(match):
            val = match.group(0)
            if "circulation_fan" in val:
                return val.replace("circulation_fan", f"circulation_fan{suffix}")
            if "CIRCULATION_FAN" in val:
                return val.replace("CIRCULATION_FAN", f"CIRCULATION_FAN{suffix}")
            if "circ_fan" in val:
                return val.replace("circ_fan", f"circ_fan{suffix}")
            if "circfan" in val:
                return val.replace("circfan", f"circfan{suffix}")
            return val
            
        pattern = re.compile(r'(circulation_fan|CIRCULATION_FAN|circ_fan|circfan)[a-zA-Z0-9_]*')
        
        new_cpp = pattern.sub(repl, cpp_content)
        new_h = pattern.sub(repl, h_content)
        
        # Replace string literals like "circulation_fan" -> "circulation_fan2"
        new_cpp = new_cpp.replace('"circulation_fan"', f'"circulation_fan{suffix}"')
        new_h = new_h.replace('"circulation_fan"', f'"circulation_fan{suffix}"')
        
        # Save generated files into the root directory
        with open(f"circulation_fan{suffix}.cpp", "w", encoding="utf-8") as f:
            f.write(new_cpp)
        with open(f"circulation_fan{suffix}.h", "w", encoding="utf-8") as f:
            f.write(new_h)

def generate_block_content(marker_id, inst):
    s = str(inst)
    if marker_id == "CIRCULATION_INIT":
        return (
            f"\nif (sysConfig.pin_circ_fan{s} == -1 || sysConfig.pin_circ_tacho{s} == -1) {{\n"
            f"    Serial.println(\"Circulation Fan{s} disabled (sysConfig).\");\n"
            f"}} else {{\n"
            f"    circulation_fan{s}_init((uint8_t)sysConfig.pin_circ_fan{s}, (uint8_t)sysConfig.pin_circ_tacho{s});\n"
            f"}}"
        )
    elif marker_id == "CIRCULATION_UPDATE":
        return f"\ncirculation_fan{s}_update();"
    elif marker_id == "CIRCULATION_INCLUDE":
        return f'\n#include "circulation_fan{s}.h"'
    elif marker_id == "CIRCULATION_GET_STATUS":
        return f"\ncirculation_fan{s}_get_status(obj);"
    elif marker_id == "CIRCULATION_JSON_UPDATE":
        return f"\ncirculation_fan{s}_process_json(obj);"
    elif marker_id == "CIRCULATION_CONFIG":
        return (
            f"\nint pin_circ_fan{s};\n"
            f"int pin_circ_tacho{s};\n"
            f"int pin_circ_tacho_pull{s};"
        )
    elif marker_id == "CIRCULATION_CONFIG_DEFAULTS":
        return (
            f"\n/* pin_circ_fan{s} */ 45,\n"
            f"/* pin_circ_tacho{s} */ 2,\n"
            f"/* pin_circ_tacho_pull{s} */ 1,"
        )
    elif marker_id == "CIRCULATION_PREFS_LOAD":
        return (
            f"\nsysConfig.pin_circ_fan{s}        = growPrefs.getInt(\"p_c_fan{s}\", sysConfig.pin_circ_fan{s});\n"
            f"sysConfig.pin_circ_tacho{s}      = growPrefs.getInt(\"p_c_tac{s}\", sysConfig.pin_circ_tacho{s});\n"
            f"sysConfig.pin_circ_tacho_pull{s} = growPrefs.getInt(\"p_c_tac_pull{s}\", sysConfig.pin_circ_tacho_pull{s});"
        )
    elif marker_id == "CIRCULATION_PREFS_SAVE":
        return (
            f"\nif (doc.containsKey(\"p_c_fan{s}\")) {{\n"
            f"    int v = doc[\"p_c_fan{s}\"];\n"
            f"    growPrefs.putInt(\"p_c_fan{s}\", v);\n"
            f"    sysConfig.pin_circ_fan{s} = v;\n"
            f"    gpio_changed = true;\n"
            f"}}\n"
            f"if (doc.containsKey(\"p_c_tac_pull{s}\")) {{\n"
            f"    int v = doc[\"p_c_tac_pull{s}\"];\n"
            f"    growPrefs.putInt(\"p_c_tac_pull{s}\", v);\n"
            f"    sysConfig.pin_circ_tacho_pull{s} = v;\n"
            f"    gpio_changed = true;\n"
            f"}}\n"
            f"if (doc.containsKey(\"p_c_tac{s}\")) {{\n"
            f"    int v = doc[\"p_c_tac{s}\"];\n"
            f"    growPrefs.putInt(\"p_c_tac{s}\", v);\n"
            f"    sysConfig.pin_circ_tacho{s} = v;\n"
            f"    gpio_changed = true;\n"
            f"}}"
        )
    elif marker_id == "CIRCULATION_RECONFIGURE":
        return f"\ncirculation_fan{s}_reconfigure();"
    return ""

def patch_file(filepath, target_instances):
    if not os.path.exists(filepath):
        return
        
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
        
    pattern = r"(//\s*PATCHER\s+BEGIN:\s*(\w+)\s*\n)(.*?)(//\s*PATCHER\s+END:\s*\2)"
    
    def replacer(match):
        begin_tag = match.group(1)
        marker_id = match.group(2)
        inner_content = match.group(3)
        end_tag = match.group(4)
        
        # Reset to base instance 1 state by removing any previously patched fields for instances 2 or 3
        # Splitting to keep only the original code block logic safely
        lines = inner_content.splitlines(keepends=True)
        base_lines = []
        for line in lines:
            # Check if line contains signature references to instances 2 or 3
            if any(x in line for x in ["fan2", "tacho2", "tac2", "fan3", "tacho3", "tac3"]):
                continue
            base_lines.append(line)
            
        cleaned_base = "".join(base_lines).rstrip()
        
        # Re-generate additional entries based on targeted instances
        extended = cleaned_base
        for inst in target_instances:
            extended += generate_block_content(marker_id, inst)
            
        return f"{begin_tag}{extended}\n{end_tag}"
        
    new_content = re.sub(pattern, replacer, content, flags=re.DOTALL)
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)

def main():
    print("Select total number of instances (1, 2, or 3):")
    try:
        selection = int(input(">> ").strip())
    except ValueError:
        print("Invalid input.")
        sys.exit(1)
        
    if selection not in [1, 2, 3]:
        print("Instance count must be 1, 2, or 3.")
        sys.exit(1)
        
    target_instances = []
    if selection >= 2:
        target_instances.append(2)
    if selection == 3:
        target_instances.append(3)
        
    # Phase 1: Create duplicate copy of files if target_instances are required
    copy_and_rename_sources(target_instances)
    
    # Phase 2: Apply absolute idempotent code inject patterns
    patch_file("testble2.ino", target_instances)
    patch_file("grow_controller.cpp", target_instances)
    
    print(f"Successfully configured and patched codebase for {selection} instance(s).")

if __name__ == "__main__":
    main()