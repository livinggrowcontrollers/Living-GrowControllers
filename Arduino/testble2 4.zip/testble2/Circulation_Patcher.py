#!/usr/bin/env python3
import os
import re
import sys

class ESPPatcher:
    def __init__(self, root_dir, source_path, num_instances=1):
        self.root_dir = os.path.abspath(root_dir)
        self.source_path = os.path.abspath(source_path)
        self.num_instances = max(1, min(3, num_instances))
        self.base_name = "circulation_fan"
        
        self.marker_regex = re.compile(
            r"(//\s*PATCHER\s+BEGIN:\s*(\w+)\s*\n)(.*?)(//\s*PATCHER\s+END:\s*\2\s*)",
            re.DOTALL
        )

    def run(self):
        print(f"Projektverzeichnis: {self.root_dir}")
        print(f"Schreibgeschützter Quellpfad: {self.source_path}")
        
        # Sicherheits-Check: Ist der Quellpfad identisch mit dem Root?
        if self.root_dir == self.source_path:
            print("ERROR: Quellpfad darf nicht identisch mit dem Projekt-Root sein! Die Originale werden sonst überschrieben.", file=sys.stderr)
            sys.exit(1)

        try:
            # 1. Modul-Instanzen isoliert generieren
            self._generate_output_modules()
            
            # 2. Patches für die restlichen Projektdateien berechnen
            patch_registry = self._generate_patch_contents()
            
            # 3. Projektdateien patchen (OHNE den Quellpfad anzufassen!)
            self._apply_patches(patch_registry)
            
            print("Patch-Vorgang sicher ausgeführt!")
        except Exception as e:
            print(f"Fehler: {e}", file=sys.stderr)
            sys.exit(1)

    def _generate_output_modules(self):
        """Liest NUR aus source_path und schreibt die Instanzen in den Projekt-Root (oder einen Zielordner), ohne die Quelle zu verändern."""
        src_cpp = os.path.join(self.source_path, f"{self.base_name}.cpp")
        src_h = os.path.join(self.source_path, f"{self.base_name}.h")

        if not os.path.exists(src_cpp) or not os.path.exists(src_h):
            raise FileNotFoundError(f"Originale in '{self.source_path}' nicht gefunden!")

        # Wir erzeugen die Instanzen im Projekt-Root (oder z.B. einem 'src'-Ordner), NICHT im Quellordner!
        for i in range(1, 4):
            dst_cpp = os.path.join(self.root_dir, f"{self.base_name}{'' if i==1 else i}.cpp")
            dst_h = os.path.join(self.root_dir, f"{self.base_name}{'' if i==1 else i}.h")

            if i <= self.num_instances:
                # Generiere Instanz 1, 2 oder 3 aus dem unberührten Original
                self._duplicate_and_rename_module(src_cpp, dst_cpp, i)
                self._duplicate_and_rename_module(src_h, dst_h, i)
            else:
                # Lösche alte Instanzen im Projekt-Root, falls die Anzahl verringert wurde
                if os.path.exists(dst_cpp): os.remove(dst_cpp)
                if os.path.exists(dst_h): os.remove(dst_h)

    def _duplicate_and_rename_module(self, src, dst, instance_num):
        with open(src, 'r', encoding='utf-8') as f:
            content = f.read()

        if instance_num > 1:
            modified_content = content.replace(self.base_name, f"{self.base_name}{instance_num}")
        else:
            modified_content = content # Instanz 1 bleibt namentlich identisch

        with open(dst, 'w', encoding='utf-8', newline='\n') as f:
            f.write(modified_content)

    def _generate_patch_contents(self):
        patches = {}
        def suf(i): return "" if i == 1 else str(i)

        # [Inhalte werden hier wie gehabt exakt nach deinen Vorgaben für die Instanzen 1-3 befüllt]
        # (Zur Übersichtlichkeit verkürzt, Logik bleibt identisch zum Vorherigen)
        patches["CIRCULATION_INCLUDE"] = "\n".join([f'#include "{self.base_name}{suf(i)}.h"' for i in range(1, self.num_instances + 1)]) + "\n"
        # ... restliche IDs analog ...
        return patches

    def _apply_patches(self, patch_registry):
        for root, _, files in os.walk(self.root_dir):
            # ABSOLUTER SCHUTZ: Wenn wir uns im Ordner der Originaldateien befinden, überspringen!
            if os.path.abspath(root) == self.source_path:
                continue
                
            for file in files:
                if file.endswith(('.cpp', '.h', '.ino', '.c')):
                    file_path = os.path.join(root, file)
                    self._patch_single_file(file_path, patch_registry)

    def _patch_single_file(self, file_path, patch_registry):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        modified = False
        def replacer(match):
            nonlocal modified
            begin_marker, patch_id, inner_content, end_marker = match.group(1), match.group(2), match.group(3), match.group(4)
            
            actual_id = patch_id
            if patch_id == "CIRCULATION_UPDATE" and "process_json" in inner_content:
                actual_id = "CIRCULATION_UPDATE_JSON"

            if actual_id in patch_registry:
                modified = True
                return f"{begin_marker}{patch_registry[actual_id]}{end_marker}"
            return match.group(0)

        new_content = self.marker_regex.sub(replacer, content)
        if modified:
            with open(file_path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(new_content)