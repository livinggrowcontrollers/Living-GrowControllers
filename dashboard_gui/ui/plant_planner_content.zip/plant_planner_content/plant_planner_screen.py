# dashboard_gui/ui/plant_planner_content/plant_planner_screen.py
# TARGET-REVISION v2.0 READY - CLEANED (NO INIT HANDSHAKE)
# ESP AUTHORITATIVE VERSION
# © 2026 Dominik Rosenthal

import copy
import os
import time
from datetime import date

from kivy.clock import Clock
from kivy.graphics import Color, Rectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

from dashboard_gui.global_state_manager import GLOBAL_STATE
from dashboard_gui.ui.common.header_online import HeaderBar
from dashboard_gui.ui.common.glass_button import GlassButton
from dashboard_gui.ui.plant_planner_content.plant_card import PlantCard
from dashboard_gui.ui.plant_planner_content.plant_editor import PlantEditorPopup
from dashboard_gui.ui.scaling_utils import dp_scaled, sp_scaled
from dashboard_gui.overlays.base_revision_system import BaseRevisionSystem

ASSET_ROOT = os.path.join("dashboard_gui", "assets")


# =============================================================================
# SCREEN
# =============================================================================

class PlantPlannerScreen(Screen):

    name = "plant_planner"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        GLOBAL_STATE.ui_handler.attach_screen(
            "plant_planner",
            self
        )
        self.plants = []
        self.search_text = ""

        self.engine = BaseRevisionSystem()
        self._user_active = False
        self._last_user_action = 0
        # Init-Revisions-Variablen entfernt, nur noch Tracking für normales Rev

        self._last_day = date.today()
        
        Clock.schedule_interval(
            self._check_day_rollover,
            30
        )        
        # =========================================================
        # ROOT
        # =========================================================

        self.root = BoxLayout(orientation="vertical")

        with self.root.canvas.before:
            Color(1, 1, 1, 1)
        
            self.bg_img = Rectangle(
                source=os.path.join(
                    ASSET_ROOT,
                    "background_about.png"
                ),
                pos=self.root.pos,
                size=self.root.size
            )
        
        self.root.bind(
            pos=lambda *_: setattr(self.bg_img, "pos", self.root.pos),
            size=lambda *_: setattr(self.bg_img, "size", self.root.size)
        )

        # =========================================================
        # HEADER
        # =========================================================

        self.header = HeaderBar()
        self.root.add_widget(self.header)

        # =========================================================
        # SEARCH
        # =========================================================

        topbar = BoxLayout(
            size_hint_y=None,
            height=dp_scaled(60),
            padding=[dp_scaled(15), dp_scaled(10)],
            spacing=dp_scaled(10)
        )

        self.search_input = TextInput(
            hint_text="SEARCH PLANTS...",
            multiline=False,
            background_color=(0.0, 0.0, 0.0, 0.7),
            foreground_color=(1, 1, 1, 1),
            cursor_color=(0.2, 1, 0.4, 1),
            font_size=sp_scaled(18)
        )

        self.search_input.bind(text=self._on_search)

        add_btn = GlassButton(
            text="+ NEW",
            size_hint_x=None,
            width=dp_scaled(110)
        )

        add_btn.bind(on_release=lambda *_: self.open_edit_popup())

        topbar.add_widget(self.search_input)
        topbar.add_widget(add_btn)

        self.root.add_widget(topbar)

        # =========================================================
        # SCROLL
        # =========================================================

        self.scroll = ScrollView(
            do_scroll_x=False,
            bar_width=dp(4)
        )

        # HIER DIE ÄNDERUNG: cols=2 für die zweispaltige Übersicht
        self.body = GridLayout(
            cols=2,
            spacing=dp_scaled(10),
            padding=dp_scaled(12),
            size_hint_y=None
        )

        self.body.bind(
            minimum_height=self.body.setter("height")
        )

        self.scroll.add_widget(self.body)
        self.root.add_widget(self.scroll)
        self.add_widget(self.root)

        Clock.schedule_interval(
            self._check_sync_status,
            1.0
        )

    # =============================================================================
    # ENTER
    # =============================================================================
    def on_enter(self):
        """Wird aufgerufen, sobald der Screen sichtbar wird. Direktes Laden statt Handshake."""
        Clock.schedule_once(lambda *_: self._force_reload_plants(), 0.1)

    # =============================================================================
    # PUSH
    # =============================================================================

    def _push_plants_to_esp(self, plant_updates=None):
        kwargs = {"plants": self.plants}
        if plant_updates is not None:
            kwargs = {"plant_updates": plant_updates}

        new_rev = GLOBAL_STATE.send_overlay_command(
            "plant_planner",
            **kwargs
        )

        if new_rev:
            self.engine.mark_sent(new_rev)
            print(f"[PlantPlanner] PUSH -> REV {new_rev}")

    def _force_reload_plants(self):
        mac = GLOBAL_STATE.get_active_device_id()
        if mac:
            data = GLOBAL_STATE.overlay_engine.get_buffer_data(mac)
            self.update_from_global(data)

        if data:
            web_ch = data.get("webserver", {})
            server_rev = int(web_ch.get("rev_plant_planner", 0))
            self.engine.mark_confirmed_snapshot(server_rev)

    # =============================================================================
    # SEARCH
    # =============================================================================

    def _on_search(self, instance, value):
        self.search_text = value.lower().strip()
        self.build_ui()

    def _filtered_plants(self):
        if not self.search_text:
            return self.plants

        result = []
        for p in self.plants:
            blob = (
                str(p.get("name", "")) +
                str(p.get("strain", "")) +
                str(p.get("breeder", ""))
            ).lower()

            if self.search_text in blob:
                result.append(p)

        return result

    # =============================================================================
    # UI (OPTIMIERT: ASYNCHRONES / PROGRESSIVES LADEN)
    # =============================================================================

    def build_ui(self):
        self.body.clear_widgets()
        Clock.unschedule(self._load_cards_progressive)

        filtered = self._filtered_plants()

        if not filtered:
            empty = Label(
                text="NO PLANTS FOUND",
                size_hint_y=None,
                height=dp_scaled(120),
                font_size=sp_scaled(20),
                color=(0.7, 0.7, 0.7, 1)
            )
            self.body.add_widget(empty)
            return

        self._load_cards_progressive(filtered, 0)

    def _load_cards_progressive(self, plant_list, index, *args):
        if index >= len(plant_list):
            return

        if self.manager and self.manager.current != self.name:
            return

        plant = plant_list[index]
        card = PlantCard(
            plant=plant,
            on_edit=self.open_edit_popup,
            on_duplicate=self.duplicate_plant,
            on_delete=self.delete_plant,
            on_water=self.mark_plant_watered,
            on_fertilize=self.mark_plant_fertilized,
        )
        self.body.add_widget(card)

        Clock.schedule_once(lambda dt: self._load_cards_progressive(plant_list, index + 1), 0)

    # =============================================================================
    # EDIT
    # =============================================================================

    def open_edit_popup(self, plant=None):
        popup = PlantEditorPopup(
            plant=plant,
            on_save=self._on_popup_save
        )
        popup.open()

    def _on_popup_save(self, updated_plant, is_new, original_plant):
        if is_new:
            self.plants.append(copy.deepcopy(updated_plant))
        else:
            for i, p in enumerate(self.plants):
                if p is original_plant or p == original_plant:
                    self.plants[i] = copy.deepcopy(updated_plant)
                    break

        self._push_plants_to_esp()
        self.build_ui()

    # =============================================================================
    # SAVE / DUPLICATE / DELETE
    # =============================================================================

    def _mark_plant_action(self, plant, field_name):
        timestamp = int(time.time())
        for existing in self.plants:
            if existing is plant or existing == plant:
                existing[field_name] = timestamp
                break

        self._push_plants_to_esp(
            plant_updates=[{
                "name": plant.get("name", ""),
                field_name: timestamp,
            }]
        )
        self.build_ui()

    def mark_plant_watered(self, plant):
        self._mark_plant_action(plant, "last_watered")

    def mark_plant_fertilized(self, plant):
        self._mark_plant_action(plant, "last_fertilized")

    def duplicate_plant(self, plant):
        new_plant = copy.deepcopy(plant)
        new_plant["name"] += " COPY"
        self.plants.append(new_plant)
        self._push_plants_to_esp()
        self.build_ui()

    def delete_plant(self, plant):
        if plant in self.plants:
            self.plants.remove(plant)
        self._push_plants_to_esp()
        self.build_ui()

    # =============================================================================
    # SYNC & ROLLOVER
    # =============================================================================
    def _check_sync_status(self, dt):
        data = GLOBAL_STATE.overlay_engine.get_buffer_data(
            GLOBAL_STATE.get_active_device_id()
        )
        if not data:
            return

        web_ch = data.get("webserver", {})
        server_rev = int(web_ch.get("rev_plant_planner", 0))

        # 🔥 retry handling
        if self.engine.is_pending(server_rev):
            if self.engine.should_retry():
                if self.engine.retry_allowed():
                    self.engine.register_retry()
                    self._push_plants_to_esp()
                    return

        # optional: status holen (für später UI)
        status = self.engine.get_status(
            server_rev,
            self._user_active,
            self._last_user_action
        )

    def _check_day_rollover(self, dt):
        today = date.today()
        if today != self._last_day:
            self._last_day = today
            print("[PlantPlanner] DAY CHANGED -> REFRESH UI")
            self.build_ui()

    # =============================================================================
    # UPDATE
    # =============================================================================

    def update_from_global(self, data):
        if not data:
            return
    
        self.header.update_from_global(data)
        web_ch = data.get("webserver", {})
        pp = web_ch.get("plant_planner", {})
    
        if "plants" not in pp:
            return
    
        new_plants = pp["plants"]
        if new_plants != self.plants:
            self.plants = copy.deepcopy(new_plants)
            self.build_ui()