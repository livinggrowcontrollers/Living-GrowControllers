import os
from kivy.graphics import Color, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label

from dashboard_gui.ui.common.glass_button import GlassButton
from dashboard_gui.ui.plant_planner_content import plant_logic
from dashboard_gui.ui.scaling_utils import dp_scaled, sp_scaled

ASSET_ROOT = os.path.join("dashboard_gui", "assets", "plant_pics")


class PlantCard(BoxLayout):

    @staticmethod
    def _normalize_picture(plant):
        try:
            picture = int(plant.get("picture", 1))
        except (TypeError, ValueError):
            picture = 1
        return max(1, min(10, picture))

    @classmethod
    def _picture_asset(cls, plant):
        picture = cls._normalize_picture(plant)
        return os.path.join(ASSET_ROOT, f"plant{picture:02d}.png")

    def __init__(
        self,
        plant,
        on_edit=None,
        on_duplicate=None,
        on_delete=None,
        on_water=None,
        on_fertilize=None,
        **kwargs,
    ):
        # Hauptlayout bleibt VERTIKAL -> Damit die Buttons unten die volle Breite bekommen
        super().__init__(
            orientation="vertical",
            size_hint_y=None,
            padding=dp_scaled(14),
            spacing=dp_scaled(12),
            **kwargs,
        )
        self.height = dp_scaled(340)

        with self.canvas.before:
            Color(0.0, 0.0, 0.0, 0.7)
            rect = Rectangle(pos=self.pos, size=self.size)

        self.bind(
            pos=lambda *_: setattr(rect, "pos", self.pos),
            size=lambda *_: setattr(rect, "size", self.size),
        )

        # =====================================================================
        # OBERER BEREICH: Horizontal geteilt (Bild LINKS, Text RECHTS)
        # =====================================================================
        upper_box = BoxLayout(orientation="horizontal", spacing=dp_scaled(16))

        # --- 1. LINKS: Das Pflanzenbild (Exakt aus deinem Original) ---
        plant_img = Image(
            source=self._picture_asset(plant),
            size_hint=(None, 1),
            width=dp_scaled(240),  # Originale Breite von 240dp behalten
            allow_stretch=True,
            keep_ratio=True,
        )
        upper_box.add_widget(plant_img)

        # --- 2. RECHTS: Der komplette Text-Inhalt (Vertikal gestapelt) ---
        text_content = BoxLayout(orientation="vertical", spacing=dp_scaled(8))

        # Top Bar (Titel links bündig, Phase rechts bündig)
        top = BoxLayout(size_hint_y=None, height=dp_scaled(35))
        
        title = Label(
            text=f"[b]{plant.get('name', 'Unnamed')}[/b]",
            markup=True,
            font_size=sp_scaled(22),
            halign="left",
            valign="middle",
            color=(1, 1, 1, 1),
        )
        title.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        
        phase = plant_logic.get_current_phase(plant)
        phase_lbl = Label(
            text=f"[b]{phase.upper()}[/b]",
            markup=True,
            size_hint_x=None,
            width=dp_scaled(120),
            font_size=sp_scaled(18),
            color=plant_logic.phase_color(phase),
            halign="right",
            valign="middle",
        )
        phase_lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        
        top.add_widget(title)
        top.add_widget(phase_lbl)
        text_content.add_widget(top)

        # Info Grid (Strain, Breeder, etc. sauber linksbündig untereinander)
        info_grid = GridLayout(
            cols=2, 
            size_hint_y=None, 
            height=dp_scaled(75), 
            spacing=[dp_scaled(12), dp_scaled(6)]
        )
        items = [
            ("STRAIN", plant.get("strain", "---")),
            ("BREEDER", plant.get("breeder", "---")),
            ("MEDIUM", plant.get("medium", "---")),
            ("LIGHT", plant.get("light", "---")),
        ]
        for k, v in items:
            box = BoxLayout(orientation="vertical", spacing=dp_scaled(1))
            
            k_lbl = Label(
                text=k, 
                font_size=sp_scaled(16), 
                color=(0.5, 0.5, 0.6, 1), 
                halign="left", 
                valign="middle"
            )
            k_lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            
            v_lbl = Label(
                text=str(v), 
                font_size=sp_scaled(18), 
                color=(1, 1, 1, 1), 
                halign="left", 
                valign="middle"
            )
            v_lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            
            box.add_widget(k_lbl)
            box.add_widget(v_lbl)
            info_grid.add_widget(box)
            
        text_content.add_widget(info_grid)

        # Zeiten / Tage (Modern aufgeteilt als 3-spaltiges Dashboard-Element)
        germination_days = plant_logic.calc_phase_days(plant, "germination")
        seedling_days = plant_logic.calc_phase_days(plant, "seedling")
        veg_days = plant_logic.calc_phase_days(plant, "vegetative")
        flower_days = plant_logic.calc_phase_days(plant, "flowering")
        total_days = plant_logic.calc_total_days(plant)
        combined_veg_days = germination_days + seedling_days + veg_days

        metrics_box = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp_scaled(48), spacing=dp_scaled(8))
        
        metrics_data = [
            ("VEG DAYS", f"{combined_veg_days} Days"),
            ("FLOWER DAYS", f"{flower_days} Days"),
            ("TOTAL DAYS", f"{total_days} Days")
        ]

        for label_text, value_text in metrics_data:
            m_col = BoxLayout(orientation="vertical", spacing=dp_scaled(2))
            
            m_lbl = Label(
                text=label_text, 
                font_size=sp_scaled(14), 
                color=(0.5, 0.5, 0.5, 1), 
                halign="center", 
                valign="middle"
            )
            m_lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            
            m_val = Label(
                text=f"[b]{value_text}[/b]", 
                markup=True, 
                font_size=sp_scaled(18), 
                color=(0.2, 1, 0.4, 1), 
                halign="center", 
                valign="middle"
            )
            m_val.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            
            m_col.add_widget(m_lbl)
            m_col.add_widget(m_val)
            metrics_box.add_widget(m_col)

        text_content.add_widget(metrics_box)

        quick_actions = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp_scaled(56),
            spacing=dp_scaled(8),
        )

        for label_text, field_key, callback in [
            ("WATER", "last_watered", on_water),
            ("FERTILIZE", "last_fertilized", on_fertilize),
        ]:
            action_col = BoxLayout(orientation="vertical", spacing=dp_scaled(3))
            action_btn = GlassButton(text=label_text)
            if callback:
                action_btn.bind(
                    on_release=lambda *_ , cb=callback, plant_ref=plant: cb(plant_ref)
                )

            status_lbl = Label(
                text=plant_logic.format_relative_timestamp(plant.get(field_key, 0)),
                font_size=sp_scaled(12),
                color=(0.7, 0.8, 0.8, 1),
                halign="center",
                valign="middle",
            )
            status_lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            action_col.add_widget(action_btn)
            action_col.add_widget(status_lbl)
            quick_actions.add_widget(action_col)

        text_content.add_widget(quick_actions)

        # Text-Box rechts neben dem Bild platzieren
        upper_box.add_widget(text_content)

        # Den fertigen oberen Bereich zur Hauptkarte hinzufügen
        self.add_widget(upper_box)

        # =====================================================================
        # UNTERER BEREICH: Buttons (Volle Breite, komplett getrennt)
        # =====================================================================
        btn_box = BoxLayout(
            size_hint_y=None, height=dp_scaled(48), spacing=dp_scaled(8)
        )

        edit_btn = GlassButton(text="EDIT")
        dup_btn = GlassButton(text="DUPLICATE")
        del_btn = GlassButton(text="DELETE")
        del_btn.color = (1, 0.3, 0.3, 1)

        if on_edit:
            edit_btn.bind(on_release=lambda *_: on_edit(plant))
        if on_duplicate:
            dup_btn.bind(on_release=lambda *_: on_duplicate(plant))
        if on_delete:
            del_btn.bind(on_release=lambda *_: on_delete(plant))

        btn_box.add_widget(edit_btn)
        btn_box.add_widget(dup_btn)
        btn_box.add_widget(del_btn)

        # Buttons ganz unten an die Hauptkarte hängen
        self.add_widget(btn_box)