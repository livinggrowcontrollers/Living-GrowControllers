# dashboard_gui/ui/plant_planner_content/plant_logic.py


import time
from datetime import datetime, date

PHASES = [
    "germination",
    "seedling",
    "vegetative",
    "flowering",
    "drying",
    "curing"
]


def get_current_phase(plant):
    today = date.today()
    current = "UNKNOWN"

    for phase in PHASES:
        start = plant.get(f"{phase}_start", "")
        if not start:
            continue
        try:
            s = datetime.strptime(start, "%Y-%m-%d").date()
            if s <= today:
                current = phase
        except:
            pass

    return current


def phase_color(phase):
    colors = {
        "germination": (0.4, 0.8, 0.4, 1),
        "seedling": (0.5, 0.9, 0.3, 1),
        "vegetative": (0.2, 0.7, 1, 1),
        "flowering": (0.9, 0.3, 0.9, 1),
        "drying": (1, 0.6, 0.2, 1),
        "curing": (0.8, 0.5, 1, 1)
    }
    return colors.get(phase, (0.7, 0.7, 0.7, 1))


def calc_phase_days(plant, phase):
    start_str = plant.get(f"{phase}_start", "")
    if not start_str:
        return 0

    try:
        start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
        if start_date > date.today():
            return 0

        end_date = date.today()
        phase_index = PHASES.index(phase)

        for next_phase in PHASES[phase_index + 1:]:
            next_start_str = plant.get(f"{next_phase}_start", "")
            if next_start_str:
                try:
                    next_start_date = datetime.strptime(next_start_str, "%Y-%m-%d").date()
                    if next_start_date <= date.today():
                        end_date = next_start_date
                        break
                except:
                    pass

        return max(0, (end_date - start_date).days)
    except:
        return 0


def calc_total_days(plant):
    first_start = None
    for phase in PHASES:
        start_str = plant.get(f"{phase}_start", "")
        if start_str:
            try:
                s = datetime.strptime(start_str, "%Y-%m-%d").date()
                if s <= date.today():
                    if first_start is None or s < first_start:
                        first_start = s
            except:
                pass

    if first_start is None:
        return 0

    return (date.today() - first_start).days


def format_relative_timestamp(timestamp, now=None):
    if not timestamp:
        return "Keine Daten"

    if now is None:
        now = int(time.time())

    diff = max(0, int(now) - int(timestamp))
    if diff < 3600:
        return "Gerade eben"
    if diff < 86400:
        hours = max(1, int(diff / 3600))
        return f"Vor {hours}h"

    days = max(1, int(diff / 86400))
    return f"Vor {days} Tagen"
